# drive mad

A Pen created on CodePen.

Original URL: [https://codepen.io/jaxkingofpugs-1/pen/JoYagwr](https://codepen.io/jaxkingofpugs-1/pen/JoYagwr).

drive mad game i will fix the loading issue after fall break 2025